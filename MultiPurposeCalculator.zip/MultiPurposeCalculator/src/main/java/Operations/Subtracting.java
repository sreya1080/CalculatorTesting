package Operations;

public class Subtracting {
	
	    public int subt(int a, int b){
	        return a-b;
	    }
	    public double subt(double a, double b){
	        return a-b;
	    }

}
