package Operations;

public class Addition {
	  public int plus(int a, int b){
	        return a+b;
	    }
	    public double plus(double a, double b){
	        return a+b;
	    }
}
